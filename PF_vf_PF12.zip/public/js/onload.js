/**
 * These lines of code allow us to save user preferences while navigating throughout the website's pages.
 */

window.onload = (event) => {
    set_translate();
    setDark_mode();
};